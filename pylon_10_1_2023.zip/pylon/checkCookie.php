<?php


$url = "http://flashprint.webhop.biz:7024/exesjson/checkcookie";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Accept: application/json",
   "Content-Type: application/json",
   "X-ESAPIKEY-ECOMCONNECTOR: DCNKEUAOSW5VG5Q",
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = <<<DATA
{
      "apicode":"DCNKEUAOSW5VG5Q",
	   "cookie":"EAAAAEwUna+WjN4NeiyeuGG2qo5WbLXzcS+tSADR7u95mpJ/8uyUVj/slbIBMYAhebLlPP72r6yjccippWXCrOSjSJC1z9HBtT/BoFCy9BRD3S5yIvLg3Z/xczJggPsKTQVdmbU5DemRzs8Ewyld/Kn8zpV0/7w6nB435WV4aibAUzdCsOGJ6+uca+8YqnDeog62+BRmwdE88SPh50NM23Wnzi8Og+f4PShrDjwbnU+FhTBzGczh8tl61ara3YzfRHTzKQaMGRDFDP3CQKCRNuDeYONvsm2fd1QzXqT/f38U15PZSYKZ/5IbAKBjosc9OqSfILAsMHI8KoUljIbXbZPp7JQJRMqMUROwhqPRNAy8y5zRukcDIcsZsDym/932bX++KXN4CdZ9aGHlmzp4OKEBD3mnJbe7X5sKuZTJVNqsPR+Ew5402OY2gXo5vjMvhYk3qc2EXfGEpJRx+TKUmiGcKApsH+ZOrDjOb5YamV9mYVCPu677kLV5hs/pAuPkibDLyongryE06NSfnUKy/rrB72Dq9QXRiswqWSOP3BN5qzAfVqikGzwiG1EQRrk2GznfHFek18gP6q3oYgGOkGc6mz39NgewA7BZPpRXu33VwACcokxnrcUFQnN3ipxCT6jar4zkcQ/96DuKdkoNEaUEh0zGkJLk/Ol1AJuUKG/G0spSZJ3UniGhK38O5jf6lpYEQBR1jPJ5BREapemfXDbwp/mhcgRSeiHWJygALrk4Ny+gKKpVx+He5az/uZbaF9PpW86kKCBc425CdA7yYf/mg4vxsioqgtQF6XbZ5Lun/1nUdCYKBVPs41H0lMXIA6HsVDujksZeMshCrBPM2lt1fN3r/WWqXOri3kqD0MHq9ZRsmcaw4IpEOeGHlrn1iPaavJBABwB+Or3P7LlLTVznWFE8IDqBUr1EneQtGeBbpvPbsMF1GBGaZIBjH3oHusclo5kRWLWYjqHrUER//CTXG8W+K8cppU912s5U2vrfOOXCuraw3HzhE+SL7r07p8NI1GKw8WJt5FoRqG9UW7qUrHJL3kbTN/J907K6DRL4dJYgSnG738h+e7mE+VQT5I8eynroyc45XVmo28FCUwAkPj4h7zFzFbXFhbqdqmmDbLrsGIw/OHEfEu/b5cfxlKDphlJfynjRM4HFo2q3rf0O8KJEeosItE0gAymASGDRsAc1IIwLc+taQPAQEOmQdVVDiIc4TPa6baneyihLLGci+m7qI2UcPV4YjITRr0uK+WO4+F9a9hMcMYpFAmk2nAFOaDoVKf79Ndy/c/yTeodE1wmxi9ptKtML6LUd5CPFLaax9Fl/7AvJwHyvk6Y4ibhF67RwaL0uWfhO7lsY/d5cDU14D38xUo01U9O5t/obV5ki8leru/nyy5k0YJf7xOGIyLjjbbnmJP0jd4+wtKovbi4G4FbwAG9N8R8hhNXdN9nML6w5OC7GF1T+KuBRhNSL+oESgpdEAsZ/Au9rSyN04xWSKftsPRTOrC0lBrR8S0HUTmlBJg8SyVbGS9b6AXfM5gKIW1YqmSKJV8d9y7rrRcydqVzkzjViL56cJHYFQl3L3jZI6biuSNXi6IghPQAdeVuY9GOrZFa1eExGtplMOmTRuwkEkYdpJLactn4kd+LEM+cJXTBUIflG0+rZT5E6h0okK5v0Hd5QEAGey7YRbREEl95x6Ni+7itrZReJK9OF4FHe6BiuLz/6lhsrWLv4VAyK7ZSzg7LelizXcPTqQ7rIyr/A+573f8WruBizPdB9xZ2K+brwQOoksNtJ79sNVnqMEu1NCTK4/9xV3urndyewoOmTa92RoRqX/oQnfo1pAquGk5eQccjRnv3ZNfMW1EZNwY5kul+P+1zOCrSMtVuvAV6IZpK4my1W1b5w9SjWh/F3ELyeLhVWT+TihlAxvJGHCO6uipiQNF//ANOmIBkBc6WzVKLbuZuJ3eF9CJZNSnPM/mczZxtavfO2PyxTpEd7rqP+RooFgfb1ojphuarnTi7zMlaK0zX2j1dLiDUGGgy4G4rjZLO4DaUZcdVOPTZDIZXdyOBhyjQHQRG0p6GA5OQYeL3aF9V17+hxo9Gr"
    
}
DATA;

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
var_dump($resp);


?>



