<?php

error_reporting(E_ALL);

session_start();
$cookie_value = $_SESSION['cookie_name'];
if(isset($_SESSION['cookie_name'])) {
  echo "Connection is successful: " . $_SESSION['cookie_name'];
}

// url για connection 
$api_url = "http://flashprint.webhop.biz:7024/exesjson/getjsondata";

//return a cURL handle
$curl = curl_init($api_url);
curl_setopt($curl, CURLOPT_URL, $api_url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Accept: application/json",
   "Content-Type: application/json",
   "X-ESAPIKEY-ECOMCONNECTOR: DCNKEUAOSW5VG5Q",
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$pageSize = 50;
$page = 1;

$fp = fopen('file.csv', 'w');
$csvheaders = [];
fputcsv();

//while($page < 5){
	
/* Αυτό δουλευει
$data ='
{
	"cookie":"EAAAAKCTAO83t+xQ6n2/KGHTH7Y6fKDHxjPwjco81Evljbk5+W58JRz31AK+3Rp0fAMUr3bqIeLyg9/TVssBj7QYFdrGQFYAaovdXP+8Po84f25fp2uUEKmzYAGW+qWN60Lnz/cyHabFvWft9fcRSPwGoaYykPwW9EKTwuCleTGEkVW5pOVKGo7F65sSo8EZ8N7USoLQTjrxYnT7IRErvlTRiO3kyD9sUf/MVlq+U9Wd2lXbTaPn5EYG4XCA4swKAZlCaO97K0WBDopJZ963BpETBvNNUB4A73iLncSIj38w6gPCAZtDlnl/UTcMElz3SnloVQXJ3Txs6yiGt1wGdj+47EBrGG3tDoSQiOi2y+FFVUA7pgKaKYDmUlxNu2w5CO/4J0Wqz2JUV6Rk6iff+vkvyoEkrvPZN3CKetCM0hHP5wKKUspzOuw1YSUkZnc3O8z3BN9V+aWgudTxIFFGjG9t4y1XHJH53ewWUhJ2s2/szkDGxRb/7nIULYPzzjppKJ3WvB3il7UEB6H0BhfLH06F72eB4UsJ1oqAL85NGCC/yocWLG/fWAE5389etTb9ziUhbmvdTShEHkVIZ2s8hvV7Z/m1wrGijrmMwmxjrPLbLVxacAWenLXdpY3NL+s64atBgQC/sccIY4xcC9/QdXfb1oPfZq9BSY2749Yo9jFH+/R1yK1K5ZKcrM1amYHzOPIPn7D9lt/GG0erTNjdz9Ct/zvXjnUJMouSgtkKE2tncolIJQySztVj7iKrXDQ1PbA8ZsR0uR/hOXNuxFTI/brh3t4y0aG4QJ+UvWYzvR6+5ZB1M6WsvVOf17hErFl5JDIm5cy5SgefXzv2WPjgKCQtYQKaryh1U+cY4uYCu3l/rEiOKzpiyo8/9vKAs/WeaDDIp3wR4142UhXlcy/KyvW9Ctq0L3IR3FKpvGEwWFbeznoqFdEcPnDJlnpCtRe5kocjtRKup6yOT9un1wUrtEcOj/YAV1GEDr8NynOHKFuqQiVn1SWSyAN03ea9xj4krMmSzc+wIRFZ/zJRR8TrlBDnGONJwNutdRaAegBXILK172oKL6x+TOQZ0ltXanxMewgUkFUCfjSMMYZo0l94ryitOsYEkpvB/89aeJ8O/uH/CbYBlNQDt4AQhrAsHWCFDqCnM/a+FvsqAgjFsS4pRB0mnHVbLRJatxi0IONhFDtgDiaptnj8s2xyoUY6NXSqwCc0ijXxBAgvRzV4uj+7gICosOFPGEQLlpkwIJcaoq21L7BR6lkVZMGTzXG0HWDgH5xdDcFPIpVSUn06Wwvye5WC4ZpbS2T5nebKY13zJFme0hegbaSU+Dp5qKaBfBVfm/u4XDSuPlCo02wz5kqYhqUeVE4lI3W9unOTUrxtVlGjl6deCGGzFEzLJV+8ihAYQiZQsLjQrUJshH0RYDMJHK4u2ZxRVLcda0WMvGtGrSRqTPE2NKAd0YkXHEt9pUFO4x+IO/QAdxKEjetLcdSLq90vd6Fxi0drD5z2ACmSsjXbACav9/rV69Hk/cVJpn3phkNHpF1ebrYky0CHdIbFbLbaEImgl7LogzRLzowY2LZNDao6gCpP41paH4RBrkKI1qIRCaPW5JxkRrvGFL80b9z4zAWZFH2dzar9KZss26G53xll0Rj0ERVxnMBMs7Y2UQjEg8qTx7B7hghEcMWEmqGbVeM+jdbz6m8ux1rM+7k8I+pB0BL4SijpPDIk30SB2DjfJ+535KbCkBZlnMRwN3RFyZF/M+6XqolFbOW2Y+09kbifCcyJIz/X2CKGsin69345bmsciRdDXqLNZTngm2nt1damX+C1KHlRs9YjT5tzOBVYtnCtPFPSwBMmn4wfcCcSRw4TfhvlKEK9f3LXMAKOexmnQf0emFTeppEdzyOjPp1HjXkdgHHQr7LHBrDyJA9M/tJ1xP9ydRFa14iqQMdHv5ho3sk7EU2JpK6oVzkDfgHXOQ6ejv3Y9peZdyfH89wPp80bpGuJZAbqWEyU3BUd67rPB6IZ9hWOKdHkh80Bqbl/wzK4MY1RnLmpK89MQda7Sk0y96wlfu33kejZPV1ebNUbfZylUc995C7e0re+um/KpUEIz9uMRUmMraNUqDCBgw==",
    "apicode":"DCNKEUAOSW5VG5Q",
    "entitycode":"Items",
    "packagenumber":%s,
    "packagesize":3
} ';*/

$data =sprintf('
{
	"cookie":"%s",
    "apicode":"DCNKEUAOSW5VG5Q",
    "entitycode":"Items",
    "packagenumber":%s,
    "packagesize":8
} ', $cookie_value, $page);
				
//, $page, $pageSize);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
//curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
//curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);

//print_r($resp);

// P Y L O N - C S V

/* ------ ------ ------ Convert .json file to .csv ------ ------ ------ */

echo "<pre>";

$decoded_resp = json_decode($resp, true);
var_dump($decoded_resp);
//var_dump($decoded_resp['Data']['Items']);

echo "</pre>";
	//if(count($decoded_resp['Data']['Items']) < $pageSize){
	//	break;
	//}
//	//$page++;
	foreach ($decoded_resp['Data']['Items'] as $fields) {
	   fputcsv($fp, $fields);
	}

	
//}



fclose($fp);


?>

