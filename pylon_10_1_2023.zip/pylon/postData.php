<?php

$url = "http://flashprint.webhop.biz:7024/exesjson/postdata";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Accept: application/json",
   "Content-Type: application/json",
   "X-ESAPIKEY-ECOMCONNECTOR: DCNKEUAOSW5VG5Q",
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

//$data = <<<DATA

$data = '
{

"cookie":"EAAAAEUMjJi8wKjHNR9CxP8Qy3OhhuoMwx739zmOb24de4agzRx0hj3dyW5MqHO+G0NdEcl+NDlR1XsQG2qo+4M4p8p0pYrQLrzLRa0D+9+mlIq31bLN6TZzQ8z81iy+IYNhx+i17SUo6I5n0wiv9j2/FSc+PxgMkVkaoTHLdCTzfghVidR42IgEanC1HiUU91Ydr8yc9y9L6wxBbC7CEdWMOS17KgSPW3t+BRaozZcLxTWtv/YC46+Akzt9hnKLebeQZbG8C+YsyaQpsAN4y68rkqjLVffo/phvir/vURsgiAkGD8+VcR7XATmxX7MOKnefwF/qpm9Is0WeaROcgpyi1X1ajhJKdwKwZCprntg5gYPyPxwS074xkIkYLQgvhE2kbScZhJdyUfr4CLTeA5vsrt8OgbgZTzD6Zt4Bfak/sk9wUDvlKMBkUYkvzG4xz9zKv5tPYucSVf0eaSJl16Pp+b0NzROpS69q7mz+wv5cUEKyWjZuc8+e7+2tiQcBVhFWr1VIqc/R5oUfOX4/fnazJTyt32YAmi8cjf2G5JZF8K4jilro8LlysossI86e1cSSCZVZoA+Kjhfdi9QmQm7i8nLM+DG+AfgMngz4vV5i1Q2j5pgacJ//6QBevX3ciIWxY4P9F0bGAUg+1MDN6q9e35h4UZyuL3Wv4YBrK0iOWG0p4BUtSJ76MAjcGI7K3tte6wJqEsjtEXuIL2GpntxkFoaMQZ8XpUwfwZQTS8uVzXfMT1wv5CzILrReMhmWq72XLydvCBOYodd0bbRQP44Uku6chlDS5Ct5h213NwfRdZEL+QZKlIwx6vR+ulVnr8lu0Ywf9VKl0qS+le/MOeTUYdhO5g1WtKSkBAkZ2aoJnZ+bmqXNqmTEjm4REJxpQALXYx72EUn1+R2mAtBrPQT3buPJ4Ic0g/RqfZjpojH1hjVim9p7gW6UguEqU9bK278fEBIGtuSGAZBFrtZ9mXoIONrcbCX1WJBzrd1R/0OprE7nW1KpylCzQW9fH5cPUNQndWDhJ68D8t91xno6JofCgO9jjj6CVWBAvoP0cD/CchMrZSE8pvSC0OQIupnM8Kc1exN7U65PBPHeBkR31Ct4mFNWILvckWFfeZTbut5OMbNPR3K//XIBpw79z19EVk5ykPyPewHmuv7gQ3EVw7AAm5P5GJZHzY49ep7Cq4Nm0ujZiOhYgDfzi2mTi452h+svfUA3I1pV0SQu+ZkD5mGSw1mnS3F2cGt6TtLRCoowi1UD9etuBGzUT3/fUxyWjrYTVQdUWI6lWFJBmWw+Z1hfOKEgoypkjebTp9LGHK1yV13dHmhVLL6GlmGTOXf/eWqW4+HYXTEyOzCyKSCcI4HjLNAEnUcItlFU4nynjBdHR8wp5EKrQht8eCucuGCO4x/dQAsegf6peBKqyzgjnNhgMcxk2HqHrPjEmoPg7xnHMB5uBAsAiheZLvSnIcwIy8uEZp9vgej9uUkaDSgXL/9+hBhGpyIyVG3q6bzxSZBhCQ9IHvvgyoSXsGhCtf1ssITVsMU+u/NGfWRly3UlPXPaamXll/nTlP1rO79AY9ddXIAFFLiWC77uSWUfVUNRFLsMaZY5eFTe6Vn2vCc/MfEV7U72CK8MAyP0+Vq4CRIyDNQb7Pi1sKOcugRxVoMf86QZ/R4f4TlUHDk8nAduE6NvA+bONHWrUFWC7zK3veoPftQa5ROEf9qGzk4anewpnh+WXs1KJ4l4Iw42Zu/rxKOICKUAZHSUBsnbHn+rNGYG68wlZtLpxFf3LMHmKw2vqYp7DIBTC9VVPhs4G4/XoM8KMNNyYMe9miKlw9wl7JsOJUtQoipNQ4o44ARPcmgUODRpDnm1KR5FosQ4hb0oWiYByjxpdTuNbtfncSo6EvxT6YXrmpSnRulubx9jEDtoR39hgEc6yPsNCFpzIK/6ewoAqZxy3xdOHUNNB7CZvv84bXXQAWWaOaLEkf9nJWMb4USMhA7WaaFikrB77ekE2qkkjYDsRt2WqOYWV4kgt9z5MwA3umyDF6AGItim595HwDzKZWW60OkHbOqgVgxmnAqvrKeROJFw46gC2vNv8Y+LP55d",
    "apicode":"DCNKEUAOSW5VG5Q",
    "entitycode":"SalesOrders",
    "packagenumber":1,
    "packagesize":1000, 
	 "data":"{\"CstmEmail\":\"demo@epsilonnet.gr\",\"SeriesCode\":\"ΠΑΡ\",\"CsbrName\":\"Κύριο\",\"PmmtCode\":\"000002\",\"Lines\":[{\"CenlItemCode\":\"000000\",\"CenlPrice\":15.34,\"CenlAMeasurementQty\":5.0},{\"CenlItemCode\":\"000001\",\"CenlPrice\":5.34,\"CenlAMeasurementQty\":1.0}]}"
 
} ';
//DATA;

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
//curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
//curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
var_dump($resp);


?>

