<?php

// url για connection 
$url = "http://flashprint.webhop.biz:7024/exesjson/elogin";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Accept: application/json",
   "Content-Type: application/json",
   "X-ESAPIKEY-ECOMCONNECTOR: DCNKEUAOSW5VG5Q",
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = <<<DATA
{
      "apicode":"DCNKEUAOSW5VG5Q",
      "applicationname":"Hercules.MyPylonCommercial",
      "databasealias":"PYLONDB",
      "username":"webuser",
      "password":"!@#123qwe"  
}
DATA;

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);

$decoded_resp = json_decode($resp, true);
$result = json_decode($decoded_resp['Result'],true); 
//var_dump($result['cookie']);

$cookie_name = $result['cookie'];
echo "</br>";
//echo $decoded_resp['Result']['Cookie'];

echo $cookie_name;

session_start();
$_SESSION['cookie_name'] = $cookie_name;


?>



